const socket = io(`http://${window.location.host}`);

// Define charts with suggested min/max to prevent tiny ranges from looking huge
const tempLive = { canvas: null, chart: null, data: newChartData('#00E676', 'rgba(0, 230, 118, 0.1)'), unit: '°C', min: 15, max: 35 };
const humLive = { canvas: null, chart: null, data: newChartData('#00B0FF', 'rgba(0, 176, 255, 0.1)'), unit: '%', min: 0, max: 100 };
const lightLive = { canvas: null, chart: null, data: newChartData('#FFD600', 'rgba(255, 214, 0, 0.1)'), unit: 'lvl', min: 0, max: 1024 };

const dewLive = { canvas: null, chart: null, data: newChartData('#D500F9', 'rgba(213, 0, 249, 0.1)'), unit: '°C', min: 0, max: 30 };
const heatLive = { canvas: null, chart: null, data: newChartData('#FF3D00', 'rgba(255, 61, 0, 0.1)'), unit: '°C', min: 15, max: 45 };
const absHumLive = { canvas: null, chart: null, data: newChartData('#651FFF', 'rgba(101, 31, 255, 0.1)'), unit: 'g/m³', min: 0, max: 30 };

document.addEventListener('DOMContentLoaded', () => {
    tempLive.canvas = document.getElementById('tempChart');
    humLive.canvas = document.getElementById('humChart');
    lightLive.canvas = document.getElementById('lightChart');
    dewLive.canvas = document.getElementById('dewChart');
    heatLive.canvas = document.getElementById('heatChart');
    absHumLive.canvas = document.getElementById('absHumChart');

    socket.on('temperature', (msg) => renderChartData(tempLive, msg));
    socket.on('humidity', (msg) => renderChartData(humLive, msg));
    socket.on('light', (msg) => renderChartData(lightLive, msg));
    socket.on('dew_point', (msg) => renderChartData(dewLive, msg));
    socket.on('heat_index', (msg) => renderChartData(heatLive, msg));
    socket.on('absolute_humidity', (msg) => renderChartData(absHumLive, msg));
});

function renderChartData(obj, message, maxPoints = 30) {
    if (!message || !message.ts) return;

    let date = new Date(message.ts).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit', second: '2-digit'});
    
    obj.data.labels.push(date);
    obj.data.datasets[0].data.push(message.value);

    if (obj.data.labels.length > maxPoints) {
        obj.data.labels.shift();
        obj.data.datasets[0].data.shift();
    }

    if (!obj.chart) {
        obj.chart = new Chart(obj.canvas.getContext('2d'), {
            type: 'line',
            data: obj.data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: false,
                scales: {
                    x: { display: false },
                    y: { 
                        suggestedMin: obj.min,
                        suggestedMax: obj.max,
                        grid: { color: 'rgba(255,255,255,0.05)' },
                        ticks: { color: '#8b949e' }
                    }
                },
                elements: {
                    point: { radius: 0 },
                    line: { tension: 0.4, borderWidth: 2 }
                },
                plugins: { legend: { display: false } }
            }
        });
    } else {
        obj.chart.update();
    }
}

function newChartData(borderColor, backgroundColor) {
    return {
        labels: [],
        datasets: [{ data: [], borderColor: borderColor, backgroundColor: backgroundColor, fill: true }]
    };
}
