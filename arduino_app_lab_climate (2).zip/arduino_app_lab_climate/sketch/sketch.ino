#include <Arduino_Modulino.h>
#include <Arduino_RouterBridge.h>

ModulinoThermo thermo;
unsigned long previousMillis = 0;
const long interval = 1000;
#define LIGHT_PIN A0

void setup() {
  Bridge.begin();
  Modulino.begin(Wire1);
  thermo.begin();
}

void loop() {
  unsigned long currentMillis = millis();
  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;
    float celsius = thermo.getTemperature();
    float humidity = thermo.getHumidity();
    float light = (float)analogRead(LIGHT_PIN);

    Bridge.notify("record_sensor_samples", celsius, humidity, light);
  }
}
