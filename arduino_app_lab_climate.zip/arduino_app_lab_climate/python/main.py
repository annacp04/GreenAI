# SPDX-FileCopyrightText: Copyright (C) ARDUINO SRL (http://www.arduino.cc)
# SPDX-License-Identifier: MPL-2.0

import datetime
import os
import csv
import time
import cv2
import threading
from flask import Flask, Response, send_file
from arduino.app_bricks.dbstorage_tsstore import TimeSeriesStore
from arduino.app_bricks.web_ui import WebUI
from arduino.app_utils import App, Bridge

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
csv_file_path = os.path.join(BASE_DIR, "data_log.csv")

if not os.path.exists(csv_file_path):
    with open(csv_file_path, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Timestamp", "Temperature (C)", "Humidity (%)", "Light Level"])

app = Flask(__name__)

def generate_frames():
    camera = cv2.VideoCapture(0)
    while True:
        success, frame = camera.read()
        if not success: break
        ret, buffer = cv2.imencode('.jpg', frame)
        yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/download/csv')
def download_csv():
    return send_file(csv_file_path, as_attachment=True, download_name="greenai_climate_log.csv")

def start_flask():
    app.run(host='0.0.0.0', port=5000, threaded=True, use_reloader=False)

threading.Thread(target=start_flask, daemon=True).start()

db = TimeSeriesStore()
ui = WebUI()

def on_get_samples(resource: str, start: str, aggr_window: str):
    samples = db.read_samples(measure=resource, start_from=start, aggr_window=aggr_window, aggr_func="mean", limit=100)
    return [{"ts": s[1], "value": s[2]} for s in samples]

ui.expose_api("GET", "/get_samples/{resource}/{start}/{aggr_window}", on_get_samples)

def record_sensor_samples(celsius: float, humidity: float, light: float):
    if celsius is None or humidity is None:
        return

    try:
        with open(csv_file_path, mode='a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), float(celsius), float(humidity), float(light)])
    except Exception as e:
        print("CSV Error:", e)

    ts = int(datetime.datetime.now().timestamp() * 1000)
    db.write_sample("temperature", float(celsius), ts)
    db.write_sample("humidity", float(humidity), ts)
    db.write_sample("light", float(light), ts)

    ui.send_message('temperature', {"value": float(celsius), "ts": ts})
    ui.send_message('humidity', {"value": float(humidity), "ts": ts})
    ui.send_message('light', {"value": float(light), "ts": ts})

Bridge.provide("record_sensor_samples", record_sensor_samples)
App.run()
