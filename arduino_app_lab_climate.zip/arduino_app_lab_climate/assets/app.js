const socket = io(`http://${window.location.host}`);

const tempLive = { canvas: null, chart: null, data: newChartData('#00E676', 'rgba(0, 230, 118, 0.1)'), unit: '°C' };
const humLive = { canvas: null, chart: null, data: newChartData('#00B0FF', 'rgba(0, 176, 255, 0.1)'), unit: '%' };
const lightLive = { canvas: null, chart: null, data: newChartData('#FFD600', 'rgba(255, 214, 0, 0.1)'), unit: 'lvl' };

document.addEventListener('DOMContentLoaded', () => {
    tempLive.canvas = document.getElementById('tempChart');
    humLive.canvas = document.getElementById('humChart');
    lightLive.canvas = document.getElementById('lightChart');

    socket.on('temperature', (msg) => renderChartData(tempLive, msg));
    socket.on('humidity', (msg) => renderChartData(humLive, msg));
    socket.on('light', (msg) => renderChartData(lightLive, msg));
});

function renderChartData(obj, message, maxPoints = 20) {
    if (!message || !message.ts) return;

    let date = new Date(message.ts).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit', second: '2-digit'});
    
    obj.data.labels.push(date);
    obj.data.datasets[0].data.push(message.value);

    if (obj.data.labels.length > maxPoints) {
        obj.data.labels.shift();
        obj.data.datasets[0].data.shift();
    }

    if (!obj.chart) {
        obj.chart = new Chart(obj.canvas.getContext('2d'), {
            type: 'line',
            data: obj.data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: false,
                scales: {
                    x: { display: false },
                    y: { 
                        grid: { color: 'rgba(255,255,255,0.05)' },
                        ticks: { color: '#8b949e' }
                    }
                },
                elements: {
                    point: { radius: 0 },
                    line: { tension: 0.4, borderWidth: 2 }
                },
                plugins: { legend: { display: false } }
            }
        });
    } else {
        obj.chart.update();
    }
}

function newChartData(borderColor, backgroundColor) {
    return {
        labels: [],
        datasets: [{ data: [], borderColor: borderColor, backgroundColor: backgroundColor, fill: true }]
    };
}
